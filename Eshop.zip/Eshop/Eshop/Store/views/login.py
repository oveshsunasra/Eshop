from django.shortcuts import render,redirect, HttpResponseRedirect
from django.contrib.auth.hashers import check_password
from django.views import View
from Store.models.customer import Customer

class Login(View):
    returnUrl=None
    def get(self, request):
        Login.returnUrl = request.GET.get('returnUrl')
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)

        value = {
            'email': email
        }
        error_message = "Your Email or Password invalid"

        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer']=customer.id
                if Login.returnUrl:
                    return HttpResponseRedirect(Login.returnUrl)
                else:
                    Login.returnUrl = None
                    return redirect('homepage')
            else:

                data = {
                    'error': error_message,
                    'values': value
                }

                return render(request, 'login.html', data)
        else:

            data = {
                'error': error_message,
                'values': value
            }

            return render(request, 'login.html', data)

def logout(request):
    request.session.clear()
    return redirect('login')