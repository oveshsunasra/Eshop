from django.shortcuts import render,redirect
from django.contrib.auth.hashers import make_password
from django.views import View
from Store.models.customer import Customer


class Signup(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postdata = request.POST
        first_name = postdata.get('firstname')
        last_name = postdata.get('lastname')
        phone = postdata.get('phone')
        email = postdata.get('email')
        password = postdata.get('password')

        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
        }

        error_message = None

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)

        error_message = self.ValidateCustomer(customer)
        # Save Data
        if not error_message:
            customer.password = make_password(customer.password)
            customer.register()
            return redirect('homepage')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'signup.html', data)

    def ValidateCustomer(self, customer):
        # Validation
        error_message = None

        # FirstName Validation
        if not customer.first_name:
            error_message = "FirstName Is Required !!!"

        # LastName Validation
        elif not customer.last_name:
            error_message = "LastName Is Required !!!"

        # Phone Validation
        elif not customer.phone:
            error_message = "Phone Number Is Required !!!"
        elif len(customer.phone) < 10:
            error_message = "Phone Number Must Be 10 Digit Or More !!!"

        # Email Validation
        elif len(customer.email) < 6:
            error_message = "Email Is Required !!!"

        elif customer.isExist():
            error_message = "This Email Already Exists !!!"

        # Password Validation
        elif not customer.password:
            error_message = "Password Is Required !!!"
        elif len(customer.password) < 6:
            error_message = "Password Must Be 6 Character Or More !!!"

        return error_message