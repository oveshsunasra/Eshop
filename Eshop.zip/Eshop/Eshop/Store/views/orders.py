from django.shortcuts import render,redirect
from django.contrib.auth.hashers import check_password
from django.views import View
from Store.models.customer import Customer
from Store.models.product import Product
from Store.models.orders import Order

class Orders(View):

    def get(self, request):
        customer = request.session.get('customer')
        orders = Order.get_order_by_customer(customer)
        orders = orders.reverse()
        return render(request, 'orders.html', {'orders': orders})

