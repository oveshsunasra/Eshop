from django.shortcuts import render,redirect
from Store.models.product import Product
from Store.models.category import Category
from django.views import View

class Index(View):
    def get(self, request):
        cart=request.session.get('cart')
        if not cart:
            request.session['cart']={}
        products = None
        categories = Category.get_all_categories()
        categoryId = request.GET.get('category')
        if categoryId:
            products = Product.get_all_products_by_categoryid(categoryId)
        else:
            products = Product.get_all_product()
        data = {}
        data['products'] = products
        data['categories'] = categories
        return render(request, 'index.html', data)

    def post(self, request):
        productId = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity= cart.get(productId)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(productId)
                    else:
                        cart[productId] = quantity - 1
                else:
                    cart[productId] = quantity + 1
            else:
                cart[productId] = 1
        else:
            cart = {}
            cart[productId] = 1

        request.session['cart'] = cart
        print('cart', request.session['cart'])
        return redirect('homepage')



